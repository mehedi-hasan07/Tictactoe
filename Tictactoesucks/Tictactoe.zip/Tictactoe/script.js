const cells = document.querySelectorAll(".cell");
const statusEl = document.querySelector(".status span");
const restartBtn = document.getElementById("restartBtn");
const modeToggle = document.getElementById("modeToggle");

let currentPlayer = "X";
let board = Array(9).fill("");
let gameActive = true;
let vsAI = false;

let scores = { X: 0, O: 0 };

const winPatterns = [
  [0,1,2],[3,4,5],[6,7,8], // rows
  [0,3,6],[1,4,7],[2,5,8], // cols
  [0,4,8],[2,4,6]          // diagonals
];

function handleClick(e) {
  const idx = e.target.dataset.index;
  if (!gameActive || board[idx] !== "") return;

  makeMove(idx, currentPlayer);
  if (vsAI && gameActive && currentPlayer === "O") {
    setTimeout(aiMove, 400);
  }
}

function makeMove(idx, player) {
  board[idx] = player;
  cells[idx].textContent = player;
  cells[idx].classList.remove("empty");
  cells[idx].classList.add(player.toLowerCase());

  if (checkWin(player)) {
    showWinner(player);
    return;
  }

  if (board.every(cell => cell !== "")) {
    statusEl.textContent = "Draw!";
    gameActive = false;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusEl.textContent = `Turn: ${currentPlayer}`;
}

function checkWin(player) {
  return winPatterns.find(pattern =>
    pattern.every(idx => board[idx] === player)
  );
}

function showWinner(player) {
  const winningPattern = checkWin(player);

  // Highlight winning cells
  winningPattern.forEach(idx => {
    cells[idx].classList.add("winner");
  });

  statusEl.textContent = `${player} Wins! 🎉`;
  scores[player]++;
  updateScores();
  gameActive = false;
}

function aiMove() {
  const emptyIndices = board.map((v,i) => v==="" ? i : null).filter(v => v!==null);
  if (emptyIndices.length === 0) return;

  const idx = emptyIndices[Math.floor(Math.random()*emptyIndices.length)];
  makeMove(idx, currentPlayer);
}

function restartGame() {
  board.fill("");
  cells.forEach(cell => {
    cell.textContent = "";
    cell.className = "cell empty";
  });
  currentPlayer = "X";
  gameActive = true;
  statusEl.textContent = `Turn: ${currentPlayer}`;
}

function updateScores() {
  document.getElementById("scoreX").textContent = scores.X;
  document.getElementById("scoreO").textContent = scores.O;
}

cells.forEach(cell => cell.addEventListener("click", handleClick));
restartBtn.addEventListener("click", restartGame);

modeToggle.addEventListener("click", () => {
  vsAI = !vsAI;
  modeToggle.textContent = vsAI ? "Vs AI" : "2 Players";
  restartGame();
});

// init
restartGame();